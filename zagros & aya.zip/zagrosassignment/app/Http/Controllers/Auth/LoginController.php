<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        try {
            $credentials = $request->only('username', 'password');

            if (Auth::attempt($credentials)) {
                // Authentication passed...
                return redirect()->intended('/home');
            } else {
                return back()->withErrors(['error' => 'Invalid login credentials']);
            }
        } catch (\Exception $e) {
            // Log or display the error message
            dd($e->getMessage());
        }
    }
}
