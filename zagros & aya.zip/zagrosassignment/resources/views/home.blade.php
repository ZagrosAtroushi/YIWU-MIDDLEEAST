<!-- resources/views/home.blade.php -->
@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Welcome to our Website</h1>
    <p>This is the home page content.</p>
@endsection