<!-- resources/views/about.blade.php -->
@extends('layouts.app')

@section('title', 'About Us')

@section('content')
    <h1>About Us</h1>
    <p>This is the about page content.</p>
@endsection
